<div class="col-md-3">
<p class="lead">PACIFIC</p>
<div class="list-group">

      <?php 

//include("../../functions.php");
get_categories();

 
?>
       
         
  </div>
   </div>
